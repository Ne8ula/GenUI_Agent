use crate::geometry::Object;
use crate::math::{smooth, V3};
use std::f32::consts::{PI, TAU};

const PERIOD: f32 = 1.9;
const SPEED: f32 = 0.155;
const UPPER: f32 = 0.29;
const LOWER: f32 = 0.29;
fn forward() -> V3 {
    V3(-0.58, 0.0, 0.815).unit()
}
fn right() -> V3 {
    V3(0.815, 0.0, 0.58).unit()
}
#[derive(Debug, Clone, Copy)]
pub struct Leg {
    pub hip: V3,
    pub knee: V3,
    pub ankle: V3,
    pub stance: bool,
}

fn weight_shift(time: f32) -> V3 {
    right() * (-0.013 * (time / PERIOD * TAU).sin())
}

pub fn leg(time: f32, side: usize) -> Leg {
    let offset = side as f32 * 0.5;
    let cycle = time / PERIOD + offset;
    let phase = cycle.fract();
    let stride = SPEED * PERIOD;
    let planted = (cycle.floor() - offset) * stride;
    let swing = ((phase - 0.62) / 0.38).clamp(0.0, 1.0);
    let travel = planted + stride * smooth(swing) + stride * 0.31;
    let lift = 0.045 * (swing * PI).sin();
    let lateral = right() * if side == 0 { -0.075 } else { 0.075 };
    let ankle = forward() * travel + lateral + V3(0.0, -0.70 + lift, 0.0);
    let bob = -0.005 * (time / PERIOD * TAU * 2.0).cos();
    let hip = forward() * (time * SPEED) + lateral + weight_shift(time) + V3(0.0, -0.13 + bob, 0.0);
    let delta = ankle - hip;
    let distance = delta.length().min(UPPER + LOWER - 0.0001);
    let axis = delta.unit();
    let a = (UPPER * UPPER - LOWER * LOWER + distance * distance) / (2.0 * distance);
    let bend = (forward() - axis * forward().dot(axis)).unit();
    let knee = hip + axis * a + bend * (UPPER * UPPER - a * a).max(0.0).sqrt();
    Leg {
        hip,
        knee,
        ankle,
        stance: phase <= 0.62,
    }
}
pub fn figure(time: f32, scale: f32, origin: V3, id: &str, start: f32) -> Vec<Object> {
    let t = time.max(0.0);
    let map = |v: V3| origin + v * scale;
    let pelvis = forward() * (t * SPEED);
    let sway = weight_shift(t);
    let torso = pelvis + sway + V3(0.0, -0.005 * (t / PERIOD * TAU * 2.0).cos(), 0.0);
    let phase = t / PERIOD * TAU;
    let yaw = 0.045 * phase.sin();
    let shoulder_right = right() * yaw.cos() + forward() * yaw.sin();
    let shoulder_forward = forward() * yaw.cos() - right() * yaw.sin();
    let local = |x: f32, y: f32, z: f32| {
        let turn = smooth((y + 0.20) / 0.45);
        let r = right().lerp(shoulder_right, turn);
        let f = forward().lerp(shoulder_forward, turn);
        map(torso + r * x + V3(0.0, y, 0.0) + f * (z + 0.022 * (y + 0.13)))
    };
    let mut coat = Object::new(&format!("actor:{id}/coat"), 4.0, 0.93, start);
    // Smooth cloth envelope rather than a stack of straight tapered rings.
    let shape = |u: f32, v: f32| {
        let y = -0.41 + v * 0.66;
        let shoulder = 0.047 * (-((v - 0.83) / 0.17).powi(2)).exp();
        let width = (0.130 + 0.067 * (1.0 - v).powi(2) + shoulder)
            * (1.0 - 0.48 * smooth((v - 0.89) / 0.11));
        let angle = u * TAU;
        let hem = (1.0 - v).powi(2);
        let lag = hem * 0.012 * (phase - 0.7 + angle * 2.0).sin();
        let folds = 1.0 + (0.035 + 0.045 * hem) * (angle * 7.0 + v * 1.3).cos();
        local(
            width * angle.cos() * folds,
            y + lag,
            (0.086 + 0.025 * hem) * angle.sin() * folds + lag,
        )
    };
    coat.surface(36, 24, [62.0, 76.0], shape);
    for u in [0.0, 0.25, 0.5, 0.75] {
        coat.strand(
            (0..=16).map(|i| shape(u, i as f32 / 16.0)).collect(),
            0.52,
            false,
        );
    }
    for u in [0.34, 0.48, 0.64, 0.83] {
        coat.strand(
            (0..=14)
                .map(|i| shape(u, 0.08 + i as f32 / 14.0 * 0.82))
                .collect(),
            0.26,
            true,
        );
    }
    coat.strand(
        (0..=28).map(|i| shape(i as f32 / 28.0, 0.0)).collect(),
        0.57,
        true,
    );
    // Back belt and center seam, not front-facing lapels or face pixels.
    let belt: Vec<_> = (0..=20)
        .map(|i| shape(0.5 + i as f32 / 20.0 * 0.5, 0.50))
        .collect();
    coat.tube(&belt, 0.004 * scale, 4, [40.0, 3.0], false);
    let mut out = vec![coat];
    let mut head = Object::new(&format!("actor:{id}/head-hair"), 4.0, 0.75, start + 0.015);
    head.ellipsoid(
        local(0.0, 0.327, 0.0),
        V3(0.070, 0.088, 0.068) * scale,
        24,
        14,
        [42.0, 42.0],
    );
    // Rear cloth hood replaces the featureless dark spherical hair cap. The
    // retained stable ID is historical; all its current vertices are authored cloth.
    let mut hair = Object::new(&format!("actor:{id}/hair"), 4.0, 0.95, start + 0.035);
    hair.ellipsoid(
        local(0.0, 0.324, -0.023),
        V3(0.081, 0.096, 0.077) * scale,
        28,
        18,
        [46.0, 42.0],
    );
    hair.strand(
        (0..=24)
            .map(|i| {
                let a = i as f32 / 24.0 * PI;
                local(0.0, 0.324 + 0.096 * a.cos(), -0.023 - 0.078 * a.sin())
            })
            .collect(),
        0.44,
        true,
    );
    out.push(head);
    out.push(hair);
    for side in 0..2 {
        let l = leg(t, side);
        let sign = if side == 0 { -1.0 } else { 1.0 };
        let mut pants = Object::new(&format!("actor:{id}/leg-{side}"), 4.0, 0.75, start + 0.02);
        pants.tapered_tube(
            &[map(l.hip), map(l.knee)],
            [0.058 * scale, 0.039 * scale],
            14,
            [22.0, 38.0],
            true,
        );
        pants.tapered_tube(
            &[map(l.knee), map(l.ankle)],
            [0.039 * scale, 0.025 * scale],
            14,
            [18.0, 38.0],
            true,
        );
        let foot_phase = (t / PERIOD + side as f32 * 0.5).fract();
        let roll = if l.stance {
            0.0
        } else {
            0.28 * (((foot_phase - 0.62) / 0.38) * PI).sin()
        };
        let toe_axis = forward() * roll.cos() + V3(0.0, roll.sin(), 0.0);
        let foot = |u: f32, v: f32| {
            let a = u * TAU;
            let b = (v - 0.5) * PI;
            map(l.ankle
                + toe_axis * (0.034 + 0.075 * a.cos() * b.cos())
                + right() * (0.027 * a.sin() * b.cos())
                + V3(0.0, 0.018 * b.sin() - 0.001, 0.0))
        };
        pants.surface(16, 8, [24.0, 12.0], foot);
        pants.strand(
            (0..=24).map(|i| foot(i as f32 / 24.0, 0.5)).collect(),
            0.56,
            false,
        );
        out.push(pants);
        let shoulder = torso
            + shoulder_right * (sign * 0.143)
            + V3(0.0, 0.155, 0.0)
            + shoulder_forward * 0.0066;
        let swing = -(phase + side as f32 * PI).cos();
        let angle = swing * 0.28;
        let elbow =
            shoulder + V3(0.0, -angle.cos(), 0.0) * 0.205 + forward() * (angle.sin() * 0.205);
        let wrist = elbow
            + V3(0.0, -(angle + 0.16).cos(), 0.0) * 0.18
            + forward() * ((angle + 0.16).sin() * 0.18);
        let mut arm = Object::new(&format!("actor:{id}/arm-{side}"), 4.0, 0.85, start + 0.02);
        arm.tapered_tube(
            &[map(shoulder), map(elbow)],
            [0.057 * scale, 0.042 * scale],
            14,
            [23.0, 30.0],
            true,
        );
        arm.tapered_tube(
            &[map(elbow), map(wrist)],
            [0.042 * scale, 0.027 * scale],
            14,
            [18.0, 27.0],
            true,
        );
        // Rounded sleeve cap overlaps the coat and both sections of the sleeve;
        // wire paths still begin with the two measured arm segments above.
        arm.ellipsoid(
            map(shoulder),
            V3(0.055, 0.055, 0.055) * scale,
            14,
            10,
            [20.0, 20.0],
        );
        arm.ellipsoid(
            map(elbow),
            V3(0.043, 0.043, 0.043) * scale,
            12,
            8,
            [16.0, 16.0],
        );
        arm.ellipsoid(
            map(wrist + V3(0.0, -0.033, 0.0)),
            V3(0.024, 0.040, 0.024) * scale,
            10,
            6,
            [10.0, 14.0],
        );
        out.push(arm);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn connected_leg_lengths_and_ground_contacts() {
        for i in 0..2400 {
            let t = i as f32 / 120.0;
            for side in 0..2 {
                let l = leg(t, side);
                assert!(((l.knee - l.hip).length() - UPPER).abs() < 0.0005);
                assert!(((l.ankle - l.knee).length() - LOWER).abs() < 0.0005);
                assert!((-0.7001..=-0.6549).contains(&l.ankle.1));
                if l.stance {
                    let knee_bend = (l.knee - l.hip)
                        .unit()
                        .dot((l.ankle - l.knee).unit())
                        .clamp(-1.0, 1.0)
                        .acos();
                    assert!(
                        knee_bend < 0.50,
                        "stance leg is over-bent for this slow-walk rig"
                    );
                    let b = leg(t + 0.0001, side);
                    if b.stance {
                        assert!((l.ankle - b.ankle).length() < 0.00001);
                    }
                }
            }
        }
    }
    #[test]
    fn rendered_arm_segments_keep_their_lengths() {
        for i in 0..120 {
            for object in figure(i as f32 / 12.0, 1.0, V3(0.0, 0.0, 5.0), "test", 0.0) {
                if object.id.contains("/arm-") {
                    let upper = &object.strands[0].points;
                    let lower = &object.strands[1].points;
                    assert!(((upper[1] - upper[0]).length() - 0.205).abs() < 0.00001);
                    assert!(((lower[1] - lower[0]).length() - 0.18).abs() < 0.00001);
                    assert_eq!(upper[1], lower[0]);
                }
            }
        }
    }
    #[test]
    fn walking_moves_left_and_into_depth() {
        let d = forward() * 10.0 * SPEED;
        assert!(d.0 < 0.0 && d.2 > 0.0);
    }
}
