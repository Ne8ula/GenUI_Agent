use crate::geometry::Object;
use crate::math::{smooth, V3};
use std::f32::consts::{PI, TAU};

const PERIOD: f32 = 1.9;
const SPEED: f32 = 0.155;
const UPPER: f32 = 0.29;
const LOWER: f32 = 0.29;
fn forward() -> V3 {
    V3(-0.82, 0.0, 0.572).unit()
}
fn right() -> V3 {
    V3(0.572, 0.0, 0.82).unit()
}
#[derive(Debug, Clone, Copy)]
pub struct Leg {
    pub hip: V3,
    pub knee: V3,
    pub ankle: V3,
    pub stance: bool,
}

pub fn leg(time: f32, side: usize) -> Leg {
    let offset = side as f32 * 0.5;
    let cycle = time / PERIOD + offset;
    let phase = cycle.fract();
    let stride = SPEED * PERIOD;
    let planted = (cycle.floor() - offset) * stride;
    let swing = ((phase - 0.62) / 0.38).clamp(0.0, 1.0);
    let travel = planted + stride * smooth(swing);
    let lift = 0.082 * (swing * PI).sin();
    let lateral = right() * if side == 0 { -0.075 } else { 0.075 };
    let ankle = forward() * travel + lateral + V3(0.0, -0.70 + lift, 0.0);
    let bob = 0.007 * (time / PERIOD * TAU * 2.0).cos();
    let hip = forward() * (time * SPEED) + lateral + V3(0.0, -0.16 + bob, 0.0);
    let delta = ankle - hip;
    let distance = delta.length().min(UPPER + LOWER - 0.0001);
    let axis = delta.unit();
    let a = (UPPER * UPPER - LOWER * LOWER + distance * distance) / (2.0 * distance);
    let bend = (forward() - axis * forward().dot(axis)).unit();
    let knee = hip + axis * a + bend * (UPPER * UPPER - a * a).max(0.0).sqrt();
    Leg {
        hip,
        knee,
        ankle,
        stance: phase <= 0.62,
    }
}
pub fn figure(time: f32, scale: f32, origin: V3, id: &str, start: f32) -> Vec<Object> {
    let t = time.max(0.0);
    let map = |v: V3| origin + v * scale;
    let pelvis = forward() * (t * SPEED);
    let sway = right() * (0.013 * (t / PERIOD * TAU).sin());
    let torso = pelvis + sway + V3(0.0, 0.007 * (t / PERIOD * TAU * 2.0).cos(), 0.0);
    let phase = t / PERIOD * TAU;
    let local = |x: f32, y: f32, z: f32| map(torso + right() * x + V3(0.0, y, 0.0) + forward() * z);
    let mut coat = Object::new(&format!("actor:{id}/coat"), 4.0, 0.93, start);
    // Tailored continuous torso: shoulder, waist and hem profiles in body coordinates.
    let profile = [
        (-0.40, 0.19),
        (-0.33, 0.188),
        (-0.20, 0.153),
        (-0.05, 0.135),
        (0.10, 0.172),
        (0.20, 0.173),
        (0.23, 0.10),
    ];
    let shape = |u: f32, v: f32| {
        let r = v * (profile.len() - 1) as f32;
        let i = (r.floor() as usize).min(profile.len() - 2);
        let f = r - i as f32;
        let y = profile[i].0 + (profile[i + 1].0 - profile[i].0) * f;
        let width = profile[i].1 + (profile[i + 1].1 - profile[i].1) * f;
        let angle = u * TAU;
        let lag = (1.0 - v).powi(2) * 0.018 * (phase - 0.7 + angle * 2.0).sin();
        local(
            width * angle.cos(),
            y + lag,
            (0.08 + 0.025 * (1.0 - v)) * angle.sin() + lag,
        )
    };
    coat.surface(28, 12, [80.0, 90.0], shape);
    for u in [0.0, 0.25, 0.5, 0.75] {
        coat.strand(
            (0..=16).map(|i| shape(u, i as f32 / 16.0)).collect(),
            0.52,
            false,
        );
    }
    for u in [0.34, 0.48, 0.64, 0.83] {
        coat.strand(
            (0..=14)
                .map(|i| shape(u, 0.08 + i as f32 / 14.0 * 0.82))
                .collect(),
            0.26,
            true,
        );
    }
    coat.strand(
        (0..=28).map(|i| shape(i as f32 / 28.0, 0.0)).collect(),
        0.57,
        true,
    );
    // Back belt and center seam, not front-facing lapels or face pixels.
    let belt: Vec<_> = (0..=20)
        .map(|i| shape(0.5 + i as f32 / 20.0 * 0.5, 0.50))
        .collect();
    coat.tube(&belt, 0.004 * scale, 4, [40.0, 3.0], false);
    let mut out = vec![coat];
    let mut head = Object::new(&format!("actor:{id}/head-hair"), 4.0, 0.75, start + 0.015);
    head.ellipsoid(
        local(0.0, 0.327, 0.0),
        V3(0.092, 0.113, 0.081) * scale,
        24,
        14,
        [42.0, 42.0],
    );
    let mut hair = Object::new(&format!("actor:{id}/hair"), 11.0, 0.12, start + 0.035);
    hair.ellipsoid(
        local(0.0, 0.348, -0.020),
        V3(0.097, 0.096, 0.081) * scale,
        24,
        12,
        [44.0, 38.0],
    );
    out.push(head);
    out.push(hair);
    for side in 0..2 {
        let l = leg(t, side);
        let sign = if side == 0 { -1.0 } else { 1.0 };
        let mut pants = Object::new(&format!("actor:{id}/leg-{side}"), 4.0, 0.75, start + 0.02);
        pants.tube(
            &[map(l.hip), map(l.knee)],
            0.042 * scale,
            10,
            [18.0, 38.0],
            true,
        );
        pants.tube(
            &[map(l.knee), map(l.ankle)],
            0.030 * scale,
            10,
            [15.0, 38.0],
            true,
        );
        let foot_phase = (t / PERIOD + side as f32 * 0.5).fract();
        let roll = if l.stance {
            0.0
        } else {
            0.28 * (((foot_phase - 0.62) / 0.38) * PI).sin()
        };
        let toe_axis = forward() * roll.cos() + V3(0.0, roll.sin(), 0.0);
        let foot = |u: f32, v: f32| {
            let a = u * TAU;
            let b = (v - 0.5) * PI;
            map(l.ankle
                + toe_axis * (0.034 + 0.075 * a.cos() * b.cos())
                + right() * (0.027 * a.sin() * b.cos())
                + V3(0.0, 0.018 * b.sin() - 0.001, 0.0))
        };
        pants.surface(16, 8, [24.0, 12.0], foot);
        pants.strand(
            (0..=24).map(|i| foot(i as f32 / 24.0, 0.5)).collect(),
            0.56,
            false,
        );
        out.push(pants);
        let shoulder = torso + right() * (sign * 0.164) + V3(0.0, 0.17, 0.0);
        let swing = (phase + side as f32 * PI).sin();
        let angle = swing * 0.28;
        let elbow =
            shoulder + V3(0.0, -angle.cos(), 0.0) * 0.205 + forward() * (angle.sin() * 0.205);
        let wrist = elbow
            + V3(0.0, -(angle + 0.16).cos(), 0.0) * 0.18
            + forward() * ((angle + 0.16).sin() * 0.18);
        let mut arm = Object::new(&format!("actor:{id}/arm-{side}"), 4.0, 0.85, start + 0.02);
        arm.tube(
            &[map(shoulder), map(elbow)],
            0.045 * scale,
            10,
            [17.0, 30.0],
            true,
        );
        arm.tube(
            &[map(elbow), map(wrist)],
            0.033 * scale,
            10,
            [14.0, 27.0],
            true,
        );
        arm.ellipsoid(
            map(wrist + V3(0.0, -0.033, 0.0)),
            V3(0.024, 0.040, 0.024) * scale,
            10,
            6,
            [10.0, 14.0],
        );
        out.push(arm);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn connected_leg_lengths_and_ground_contacts() {
        for i in 0..2400 {
            let t = i as f32 / 120.0;
            for side in 0..2 {
                let l = leg(t, side);
                assert!(((l.knee - l.hip).length() - UPPER).abs() < 0.0005);
                assert!(((l.ankle - l.knee).length() - LOWER).abs() < 0.0005);
                assert!(l.ankle.1 >= -0.7001);
                if l.stance {
                    let b = leg(t + 0.0001, side);
                    if b.stance {
                        assert!((l.ankle - b.ankle).length() < 0.00001);
                    }
                }
            }
        }
    }
    #[test]
    fn rendered_arm_segments_keep_their_lengths() {
        for i in 0..120 {
            for object in figure(i as f32 / 12.0, 1.0, V3(0.0, 0.0, 5.0), "test", 0.0) {
                if object.id.contains("/arm-") {
                    let upper = &object.strands[0].points;
                    let lower = &object.strands[1].points;
                    assert!(((upper[1] - upper[0]).length() - 0.205).abs() < 0.00001);
                    assert!(((lower[1] - lower[0]).length() - 0.18).abs() < 0.00001);
                    assert_eq!(upper[1], lower[0]);
                }
            }
        }
    }
    #[test]
    fn walking_moves_left_and_into_depth() {
        let d = forward() * 10.0 * SPEED;
        assert!(d.0 < 0.0 && d.2 > 0.0);
    }
}
