use crate::{geometry::{Frame,STRIDE},math::ASPECT,materials,scene::{Scene,SCENE_ID}};
use wasm_bindgen::{prelude::*,JsCast};
use web_sys::{HtmlCanvasElement,WebGl2RenderingContext as Gl,WebGlBuffer,WebGlProgram,WebGlShader,WebGlVertexArrayObject};

fn error(s:impl AsRef<str>)->JsValue {JsValue::from_str(s.as_ref())}
fn compile(gl:&Gl,kind:u32,source:&str)->Result<WebGlShader,JsValue> {
    let shader=gl.create_shader(kind).ok_or_else(||error("WebGL shader allocation failed"))?;
    gl.shader_source(&shader,source);gl.compile_shader(&shader);
    if !gl.get_shader_parameter(&shader,Gl::COMPILE_STATUS).as_bool().unwrap_or(false) {
        let reason=gl.get_shader_info_log(&shader).unwrap_or_default();gl.delete_shader(Some(&shader));return Err(error(reason));
    } Ok(shader)
}
fn program(gl:&Gl)->Result<WebGlProgram,JsValue> {
    let vertex=compile(gl,Gl::VERTEX_SHADER,materials::VERTEX)?;
    let fragment=match compile(gl,Gl::FRAGMENT_SHADER,materials::FRAGMENT){Ok(v)=>v,Err(e)=>{gl.delete_shader(Some(&vertex));return Err(e);}};
    let result=(|| {
        let p=gl.create_program().ok_or_else(||error("WebGL program allocation failed"))?;
        gl.attach_shader(&p,&vertex);gl.attach_shader(&p,&fragment);gl.link_program(&p);
        if !gl.get_program_parameter(&p,Gl::LINK_STATUS).as_bool().unwrap_or(false) {
            let why=gl.get_program_info_log(&p).unwrap_or_default();gl.delete_program(Some(&p));return Err(error(why));
        } Ok(p)
    })();
    gl.delete_shader(Some(&vertex));gl.delete_shader(Some(&fragment));result
}
#[wasm_bindgen]
pub struct RustRenderer {
    canvas:HtmlCanvasElement,gl:Gl,program:WebGlProgram,buffer:WebGlBuffer,vao:WebGlVertexArrayObject,
    scene:Scene,frame:Frame,disposed:bool,draws:u32,context_extension:Option<js_sys::Object>,cached_inputs:Option<[f64;6]>,
}
#[wasm_bindgen]
impl RustRenderer {
    #[wasm_bindgen(constructor)]
    pub fn new(canvas:HtmlCanvasElement,seed:u32,density:f32)->Result<RustRenderer,JsValue> {
        let scene=Scene::new(seed,density).map_err(error)?;
        let options=js_sys::Object::new();
        for (key,value) in [("alpha",false),("antialias",true),("preserveDrawingBuffer",true),("depth",true)] {
            js_sys::Reflect::set(&options,&JsValue::from_str(key),&JsValue::from_bool(value))?;
        }
        let gl:Gl=canvas.get_context_with_context_options("webgl2",&options)?.ok_or_else(||error("Rust WebGL2 unavailable; no image or TypeScript fallback"))?.dyn_into()?;
        let p=program(&gl)?;
        let Some(buffer)=gl.create_buffer() else {gl.delete_program(Some(&p));return Err(error("WebGL buffer allocation failed"));};
        let Some(vao)=gl.create_vertex_array() else {gl.delete_buffer(Some(&buffer));gl.delete_program(Some(&p));return Err(error("WebGL vertex array allocation failed"));};
        gl.bind_vertex_array(Some(&vao));gl.bind_buffer(Gl::ARRAY_BUFFER,Some(&buffer));
        for (location,size,offset) in [(0,3,0),(1,3,12),(2,2,24),(3,4,32)] {
            gl.enable_vertex_attrib_array(location);gl.vertex_attrib_pointer_with_i32(location,size,Gl::FLOAT,false,(STRIDE*4) as i32,offset);
        }
        gl.bind_vertex_array(None);
        let context_extension=gl.get_extension("WEBGL_lose_context").ok().flatten();
        Ok(Self{canvas,gl,program:p,buffer,vao,scene,frame:Frame::default(),disposed:false,draws:0,context_extension,cached_inputs:None})
    }
    pub fn render(&mut self,time_ms:f64,build_ms:f64,reduced:bool,tiles:bool,width:u32,height:u32)->Result<bool,JsValue> {
        if self.disposed{return Err(error("Rust renderer disposed"));}
        if self.gl.is_context_lost(){return Ok(false);}
        if width==0||height==0||width>4096||height>4096||u64::from(width)*u64::from(height)>8_388_608 {return Err(error("framebuffer exceeds bounded 4096 / 8-megapixel budget"));}
        if !time_ms.is_finite() || !build_ms.is_finite() || !(0.0..=3_600_000.0).contains(&time_ms) || !(0.0..=60_000.0).contains(&build_ms) {return Err(error("time/build outside renderer bounds"));}
        let inputs=[if reduced{0.0}else{time_ms},if reduced{0.0}else{build_ms},if reduced{1.0}else{0.0},if tiles{1.0}else{0.0},width as f64,height as f64];
        // Paused and reduced states require no new GPU work. This retains the live
        // framebuffer, not a captured image; resize/flags/context replacement invalidate it.
        if self.cached_inputs==Some(inputs){return Ok(true);}
        self.scene.frame(&mut self.frame,time_ms,build_ms,reduced,tiles).map_err(error)?;
        if self.canvas.width()!=width {self.canvas.set_width(width);}
        if self.canvas.height()!=height {self.canvas.set_height(height);}
        let gl=&self.gl;
        gl.disable(Gl::SCISSOR_TEST);gl.viewport(0,0,width as i32,height as i32);
        gl.clear_color(0.055,0.025,0.012,1.0);gl.clear_depth(1.0);gl.depth_mask(true);gl.clear(Gl::COLOR_BUFFER_BIT|Gl::DEPTH_BUFFER_BIT);
        let w=(height as f32*ASPECT).min(width as f32).round() as i32;let h=(w as f32/ASPECT).round() as i32;
        gl.viewport((width as i32-w)/2,(height as i32-h)/2,w,h);
        gl.enable(Gl::DEPTH_TEST);gl.depth_func(Gl::LEQUAL);gl.disable(Gl::CULL_FACE);
        gl.enable(Gl::BLEND);gl.blend_func(Gl::SRC_ALPHA,Gl::ONE_MINUS_SRC_ALPHA);
        gl.use_program(Some(&self.program));gl.bind_vertex_array(Some(&self.vao));gl.bind_buffer(Gl::ARRAY_BUFFER,Some(&self.buffer));
        for (values,mode) in [(&self.frame.triangles,Gl::TRIANGLES),(&self.frame.lines,Gl::LINES)] {
            // View lifetime ends before any subsequent Rust allocation/growth.
            let data=unsafe{js_sys::Float32Array::view(values)};
            gl.buffer_data_with_array_buffer_view(Gl::ARRAY_BUFFER,&data,Gl::DYNAMIC_DRAW);
            gl.draw_arrays(mode,0,(values.len()/STRIDE) as i32);
        }
        gl.bind_vertex_array(None);
        let e=gl.get_error();if e!=Gl::NO_ERROR{return Err(error(format!("Rust WebGL draw error {e}")));}
        self.cached_inputs=Some(inputs);self.draws=self.draws.saturating_add(1);Ok(true)
    }
    pub fn stats(&self)->String {
        format!("{{\"sceneId\":\"{}\",\"vertices\":{},\"triangles\":{},\"segments\":{},\"objects\":{},\"tiles\":{},\"draws\":{},\"cpuBufferBytes\":{}}}",SCENE_ID,(self.frame.triangles.len()+self.frame.lines.len())/STRIDE,self.frame.surfaces,self.frame.segments,self.frame.objects,self.frame.tiles,self.draws,(self.frame.triangles.capacity()+self.frame.lines.capacity())*4)
    }
    pub fn device(&self)->String {
        let parameter=if self.gl.get_extension("WEBGL_debug_renderer_info").ok().flatten().is_some(){0x9246}else{Gl::RENDERER};
        let device=self.gl.get_parameter(parameter).ok().and_then(|v|v.as_string()).unwrap_or_else(||"WebGL2 device unreported".into());
        format!("Rust/WASM procedural WebGL2 — {device}")
    }
    pub fn dispose(&mut self) {
        if self.disposed{return;}
        if !self.gl.is_context_lost() {
            self.gl.delete_buffer(Some(&self.buffer));self.gl.delete_vertex_array(Some(&self.vao));self.gl.delete_program(Some(&self.program));
        }
        self.frame=Frame::default();self.scene.objects.clear();self.disposed=true;
    }
    pub fn lose_context(&self) {
        if let Some(extension)=&self.context_extension {
            if let Ok(f)=js_sys::Reflect::get(&extension,&JsValue::from_str("loseContext")) {
                if let Ok(f)=f.dyn_into::<js_sys::Function>() {let _=f.call0(&extension);}
            }
        }
    }
    pub fn restore_context(&self) {
        if let Some(extension)=&self.context_extension {
            if let Ok(f)=js_sys::Reflect::get(&extension,&JsValue::from_str("restoreContext")) {
                if let Ok(f)=f.dyn_into::<js_sys::Function>() {let _=f.call0(&extension);}
            }
        }
    }
}
impl Drop for RustRenderer {fn drop(&mut self){self.dispose();}}
