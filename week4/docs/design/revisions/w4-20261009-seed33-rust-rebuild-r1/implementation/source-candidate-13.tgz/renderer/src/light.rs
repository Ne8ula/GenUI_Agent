// A bounded live-output light pass. This texture is cleared and redrawn from Rust
// geometry each frame; it never contains a reference image or construction reveal.
use crate::gpu::program_sources;
use wasm_bindgen::JsValue;
use web_sys::{
    WebGl2RenderingContext as Gl, WebGlFramebuffer, WebGlProgram, WebGlRenderbuffer, WebGlTexture,
};

const VERTEX: &str = r#"#version 300 es
precision highp float;
out vec2 uv;
void main(){
  vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));
  uv=p;gl_Position=vec4(p*2.0-1.0,0,1);
}
"#;
const FRAGMENT: &str = r#"#version 300 es
precision highp float;
uniform sampler2D liveScene;
in vec2 uv;
out vec4 colour;
vec3 bright(vec2 p){
  vec3 c=texture(liveScene,p).rgb;
  float y=dot(c,vec3(0.2126,0.7152,0.0722));
  return c*smoothstep(0.36,0.92,y);
}
void main(){
  vec2 px=1.0/vec2(textureSize(liveScene,0));
  vec3 base=texture(liveScene,uv).rgb;
  vec3 glow=bright(uv)*0.16;
  for(int i=0;i<8;i++){
    float a=float(i)*0.78539816;vec2 d=vec2(cos(a),sin(a))*px;
    glow+=bright(uv+d*2.0)*0.065+bright(uv+d*5.0)*0.04;
  }
  // Screen blend preserves dark gaps and warm highlight colour without a veil.
  colour=vec4(1.0-(1.0-base)*(1.0-glow*0.62),1);
}
"#;

pub struct LightPass {
    gl: Gl,
    program: Option<WebGlProgram>,
    colour: Option<WebGlTexture>,
    depth: Option<WebGlRenderbuffer>,
    target: Option<WebGlFramebuffer>,
    size: (u32, u32),
}
impl LightPass {
    pub fn new(gl: &Gl) -> Result<Self, JsValue> {
        // Options make partial setup failures use the same resource cleanup path.
        let mut pass = Self {
            gl: gl.clone(),
            program: None,
            colour: None,
            depth: None,
            target: None,
            size: (0, 0),
        };
        pass.program = Some(program_sources(gl, VERTEX, FRAGMENT)?);
        pass.colour = Some(
            gl.create_texture()
                .ok_or_else(|| JsValue::from_str("live light texture allocation failed"))?,
        );
        pass.depth = Some(
            gl.create_renderbuffer()
                .ok_or_else(|| JsValue::from_str("live light depth allocation failed"))?,
        );
        pass.target = Some(
            gl.create_framebuffer()
                .ok_or_else(|| JsValue::from_str("live light framebuffer allocation failed"))?,
        );
        Ok(pass)
    }
    pub fn begin(&mut self, width: u32, height: u32) -> Result<(), JsValue> {
        if width == 0
            || height == 0
            || width > 4096
            || height > 4096
            || u64::from(width) * u64::from(height) > 8_388_608
        {
            return Err(JsValue::from_str(
                "live light target exceeds framebuffer budget",
            ));
        }
        let gl = &self.gl;
        gl.bind_framebuffer(Gl::FRAMEBUFFER, self.target.as_ref());
        if self.size != (width, height) {
            gl.active_texture(Gl::TEXTURE0);
            gl.bind_texture(Gl::TEXTURE_2D, self.colour.as_ref());
            for name in [Gl::TEXTURE_MIN_FILTER, Gl::TEXTURE_MAG_FILTER] {
                gl.tex_parameteri(Gl::TEXTURE_2D, name, Gl::LINEAR as i32);
            }
            for name in [Gl::TEXTURE_WRAP_S, Gl::TEXTURE_WRAP_T] {
                gl.tex_parameteri(Gl::TEXTURE_2D, name, Gl::CLAMP_TO_EDGE as i32);
            }
            gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
                Gl::TEXTURE_2D,
                0,
                Gl::RGBA8 as i32,
                width as i32,
                height as i32,
                0,
                Gl::RGBA,
                Gl::UNSIGNED_BYTE,
                None,
            )?;
            gl.framebuffer_texture_2d(
                Gl::FRAMEBUFFER,
                Gl::COLOR_ATTACHMENT0,
                Gl::TEXTURE_2D,
                self.colour.as_ref(),
                0,
            );
            gl.bind_renderbuffer(Gl::RENDERBUFFER, self.depth.as_ref());
            gl.renderbuffer_storage(
                Gl::RENDERBUFFER,
                Gl::DEPTH_COMPONENT24,
                width as i32,
                height as i32,
            );
            gl.framebuffer_renderbuffer(
                Gl::FRAMEBUFFER,
                Gl::DEPTH_ATTACHMENT,
                Gl::RENDERBUFFER,
                self.depth.as_ref(),
            );
            if gl.check_framebuffer_status(Gl::FRAMEBUFFER) != Gl::FRAMEBUFFER_COMPLETE
                || gl.get_error() != Gl::NO_ERROR
            {
                return Err(JsValue::from_str(
                    "live light framebuffer incomplete or allocation failed",
                ));
            }
            self.size = (width, height);
        }
        // Do not leave the render attachment bound as a source while drawing it.
        gl.bind_texture(Gl::TEXTURE_2D, None);
        Ok(())
    }
    pub fn finish(&self) {
        let gl = &self.gl;
        gl.bind_framebuffer(Gl::FRAMEBUFFER, None);
        gl.viewport(0, 0, self.size.0 as i32, self.size.1 as i32);
        gl.disable(Gl::DEPTH_TEST);
        gl.disable(Gl::BLEND);
        gl.use_program(self.program.as_ref());
        gl.active_texture(Gl::TEXTURE0);
        gl.bind_texture(Gl::TEXTURE_2D, self.colour.as_ref());
        gl.draw_arrays(Gl::TRIANGLES, 0, 3);
        gl.bind_texture(Gl::TEXTURE_2D, None);
    }
    pub fn requested_bytes(&self) -> usize {
        // RGBA8 + a conservatively four-byte-accounted depth24 attachment.
        self.size.0 as usize * self.size.1 as usize * 8
    }
}
impl Drop for LightPass {
    fn drop(&mut self) {
        if self.gl.is_context_lost() {
            return;
        }
        self.gl.delete_framebuffer(self.target.as_ref());
        self.gl.delete_renderbuffer(self.depth.as_ref());
        self.gl.delete_texture(self.colour.as_ref());
        self.gl.delete_program(self.program.as_ref());
    }
}
