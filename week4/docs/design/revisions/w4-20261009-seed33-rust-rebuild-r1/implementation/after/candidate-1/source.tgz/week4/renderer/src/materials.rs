// Procedural material programs authored here in Rust's renderer source. No sampler,
// scene image, runtime-provided GLSL, or screen-space noise enters either program.
pub const VERTEX:&str=r#"#version 300 es
precision highp float;
layout(location=0) in vec3 position;
layout(location=1) in vec3 normal;
layout(location=2) in vec2 localCell;
layout(location=3) in vec4 material;
out vec3 vNormal;
out vec3 vPosition;
out vec2 vCell;
out vec4 vMaterial;
void main(){
  float nearZ=0.1, farZ=30.0;
  gl_Position=vec4(2.0*position.x,2.0*(2752.0/1536.0)*position.y,
    (farZ+nearZ)/(farZ-nearZ)*position.z-2.0*farZ*nearZ/(farZ-nearZ),position.z);
  vNormal=normal;vPosition=position;vCell=localCell;vMaterial=material;
}
"#;
pub const FRAGMENT:&str=r#"#version 300 es
precision highp float;
in vec3 vNormal;
in vec3 vPosition;
in vec2 vCell;
in vec4 vMaterial;
out vec4 colour;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7))+vMaterial.w*0.113)*43758.5453);}
float dotPattern(vec2 uv,float radius){
  float dist=length(fract(uv)-0.5);
  float aa=max(length(fwidth(uv))*0.38,0.035);
  return 1.0-smoothstep(radius-aa,radius+aa,dist);
}
void main(){
  float m=vMaterial.x,detail=vMaterial.y,light=vMaterial.z;
  vec3 bone=vec3(1.0,0.875,0.715),voidTone=vec3(0.055,0.025,0.012);
  if(m<0.0){colour=vec4(bone*light,0.86);return;}
  if(m>5.5&&m<6.5){colour=vec4(vec3(0.988,0.89,0.826),1);return;}
  if(m>6.5&&m<10.5){
    vec3 pigment=m<7.5?vec3(0.80,0.46,0.34):m<8.5?vec3(0.80,0.60,0.37):vec3(0.97,0.85,0.68);
    float ink=1.0;
    if(m>8.5&&m<9.5) ink=mod(floor(vCell.x)+floor(vCell.y),2.0)<1.0?1.0:0.0;
    if(m>9.5) ink=dotPattern(vCell,0.26);
    colour=vec4(mix(voidTone,pigment,ink),1);return;
  }
  vec3 n=normalize(vNormal+vec3(0.00001));vec3 eye=normalize(-vPosition);
  float rim=pow(1.0-abs(dot(n,eye)),2.0);
  float illumination=0.25+0.45*abs(dot(n,normalize(vec3(-0.4,0.8,-0.6))))+0.7*rim;
  float bead=dotPattern(vCell,0.22+rim*0.12);
  float occupancy=step(0.07,hash(floor(vCell)));
  float strand=1.0-smoothstep(0.045,0.14,abs(fract(vCell.x)-0.5));
  float pattern=bead*occupancy;
  vec3 base=bone*0.12*light;
  if(m<0.5){
    pattern=max(pattern*0.65,strand*0.56*step(0.23,hash(vec2(floor(vCell.x),0))));
    illumination=0.58; base=voidTone*1.3;
  }else if(m<1.5){pattern=max(pattern,strand*0.18);base=bone*(0.08+0.13*illumination);}
  else if(m<2.5){pattern=max(pattern,strand*0.22);base=vec3(0.17,0.093,0.041);}
  else if(m<3.5){pattern=max(pattern,strand*0.55);illumination=0.94;base=bone*0.14;}
  else if(m<4.5){
    float fold=0.68+0.32*sin(vCell.x*0.28+sin(vCell.y*0.07));
    pattern*=fold;illumination=0.6+0.75*rim;base=bone*0.11;
  }else if(m<5.5){
    float glass=max(pattern*0.36,strand*0.25)+rim*0.32;
    colour=vec4(bone*light,clamp(glass*detail+0.06,0.0,0.7));return;
  }else if(m>10.5){
    colour=vec4(voidTone+bone*pattern*light*detail*0.45,1);return;
  }
  vec3 ink=voidTone+bone*pattern*illumination*light;
  colour=vec4(mix(base,ink,detail),1);
}
"#;
