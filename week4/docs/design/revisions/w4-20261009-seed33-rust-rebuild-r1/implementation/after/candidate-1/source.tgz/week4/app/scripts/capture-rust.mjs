// Browser evidence for the real Rust/WASM path. Never synthesizes scene pixels.
// node scripts/capture-rust.mjs <new absolute output directory> [port]
import { createRequire } from 'node:module';
import { spawn } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const app = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(path.join(app, 'package.json'));
const { chromium } = require('playwright');
const output = process.argv[2];
const port = Number(process.argv[3] || 1459);
if (!output || !path.isAbsolute(output)) throw new Error('New absolute output directory required');
await mkdir(output, { recursive: false });
const report = { startedAt: new Date().toISOString(), viewport: { width: 1920, height: 1080 }, dpr: 1, checks: [], captures: [], requests: [], blocked: [], errors: [], performance: null };
const check = (name, ok, details) => { report.checks.push({ name, ok: Boolean(ok), details }); };
const server = spawn(process.execPath, [path.join(path.dirname(require.resolve('vite/package.json')), 'bin/vite.js'), '--host', '127.0.0.1', '--port', String(port), '--strictPort'], { cwd: app, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
let browser;
try {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Vite readiness timeout')), 60000);
    const consume = (data) => { if (data.toString().includes('Local:')) { clearTimeout(timer); resolve(); } };
    server.stdout.on('data', consume);server.stderr.on('data', consume);
    server.once('error', (error) => { clearTimeout(timer); reject(error); });
    server.once('exit', (code) => { clearTimeout(timer); reject(new Error(`Vite exit ${code}`)); });
  });
  browser = await chromium.launch({ headless: true, ...(process.platform === 'win32' ? { channel: 'chrome' } : {}) });
  const context = await browser.newContext({ viewport: report.viewport, deviceScaleFactor: 1 });
  await context.route('**/*', async (route) => {
    const url = route.request().url();
    if (/\.(png|jpe?g|webp|avif|gif|mp4|webm|svg)(?:\?|$)/i.test(url) || /seed33\/.+manifest\.json/.test(url)) {
      report.blocked.push(url); await route.abort('blockedbyclient');
    } else await route.continue();
  });
  const page = await context.newPage();
  page.on('pageerror', (error) => report.errors.push(error.message));
  page.on('request', (request) => report.requests.push(request.url()));
  const url = (params) => `http://127.0.0.1:${port}/?fixture=1&look=seed33&seed=33&build=12000&${new URLSearchParams(params)}`;
  const data = () => page.locator('canvas[data-ready="1"]').evaluate((c) => ({ ...c.dataset }));
  const ready = async () => { await page.waitForSelector('canvas[data-ready="1"]', { timeout: 60000 }); await page.evaluate(() => document.fonts.ready); };
  for (const [name, time] of [['structure', 1800], ['base', 5700], ['detail', 9000], ['formed', 12000], ['late', 22000]]) {
    await page.goto(url({ capture: '1', clock: 'manual', t: String(time) }));
    await ready();
    const dataset = await data();
    await page.screenshot({ path: path.join(output, `${name}-${time}.png`) });
    const pixels = await page.evaluate(() => {
      const c = document.querySelector('canvas'); const gl = c.getContext('webgl2');
      const rgba = new Uint8Array(c.width * c.height * 4);gl.readPixels(0, 0, c.width, c.height, gl.RGBA, gl.UNSIGNED_BYTE, rgba);
      let light = 0, varied = 0;
      for (let i = 0; i < rgba.length; i += 4) { if (rgba[i] > 100) light++; if (rgba[i] > 25 || rgba[i + 1] > 20 || rgba[i + 2] > 20) varied++; }
      return { light, varied, total: c.width * c.height };
    });
    report.captures.push({ name, time, dataset, pixels });
    check(`${name}: actual Rust module/frame`, dataset.renderer === 'rust-wasm' && Number(dataset.timeMs) === time && Number(dataset.segments) > 0, dataset);
    check(`${name}: visible nonempty content with images blocked`, pixels.light > 1000 && pixels.varied > 10000, pixels);
  }
  await page.goto(url({ clock: 'manual', paused: '1', t: '18000' }));await ready();
  const before = await data();
  await page.getByRole('button', { name: 'Tiles: on', exact: true }).click();
  await page.waitForFunction(() => document.querySelector('canvas')?.dataset.tiles === '0');
  const hidden = await data();
  check('tile visibility preserves clock', before.timeMs === hidden.timeMs && hidden.tiles === '0', hidden);
  await page.getByRole('button', { name: 'Tiles: off', exact: true }).click();
  await page.waitForFunction(() => Number(document.querySelector('canvas')?.dataset.tiles) === 22);
  await page.evaluate(() => window.__evaFixture.step(1000));
  check('manual stepping is exact', Number((await data()).timeMs) === 19000, await data());
  await page.getByRole('button', { name: 'Reduced motion: off', exact: true }).click();
  await page.waitForFunction(() => document.querySelector('canvas')?.dataset.reduced === '1');
  const reducedA = await page.locator('canvas').screenshot();
  await page.evaluate(() => window.__evaFixture.step(1000));
  const reducedB = await page.locator('canvas').screenshot();
  check('reduced pixels invariant across time', reducedA.equals(reducedB));
  await page.getByLabel('Backend', { exact: true }).selectOption('canvas2d');
  await page.getByRole('alert').waitFor();
  check('unsupported backend fails closed', !(await page.locator('canvas[data-ready="1"]').count()) && (await page.getByRole('alert').innerText()).includes('no raster fallback'));
  await page.getByLabel('Backend', { exact: true }).selectOption('webgl2');await ready();
  check('backend remount preserves clock', Number((await data()).timeMs) === 20000, await data());
  await page.evaluate(() => window.__evaFixture.loseContext());
  await page.waitForFunction(() => document.querySelector('canvas')?.dataset.degraded === '1');
  check('context loss clears readiness', !(await page.locator('canvas[data-ready="1"]').count()));
  await page.evaluate(() => window.__evaFixture.restoreContext());await ready();
  check('context restored at same time', Number((await data()).timeMs) === 20000, await data());
  await page.setViewportSize({ width: 390, height: 844 });await page.waitForTimeout(300);
  await page.screenshot({ path: path.join(output, 'narrow-controls.png') });
  check('narrow page does not overflow', await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  await context.close();
  check('no runtime scene-image requests', report.blocked.length === 0, report.blocked);
  check('WASM was actually requested', report.requests.some((u) => u.includes('.wasm')));
  check('no page errors', report.errors.length === 0, report.errors);
} catch (error) { report.errors.push(error.stack || String(error)); }
finally { await browser?.close(); server.kill(); }
report.finishedAt = new Date().toISOString();
report.ok = report.errors.length === 0 && report.checks.every((c) => c.ok);
await writeFile(path.join(output, 'checks.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ ok: report.ok, checks: report.checks.length, failures: report.checks.filter((c) => !c.ok), errors: report.errors, output }, null, 2));
process.exitCode = report.ok ? 0 : 1;
