mod gait;
mod geometry;
mod math;
mod materials;
mod scene;

#[cfg(target_arch="wasm32")]
mod gpu;
#[cfg(target_arch="wasm32")]
pub use gpu::RustRenderer;

#[cfg(test)]
mod tests {
    use super::{geometry::*,math::*,scene::*};
    #[test] fn authored_scene_has_stable_ids_and_no_invalid_vertices() {
        let scene=Scene::new(33,1.0).unwrap();
        let mut ids=std::collections::HashSet::new();
        for o in &scene.objects {assert!(ids.insert(&o.id));assert_eq!(o.vertices.len()%3,0);
            for v in &o.vertices {assert!(v.p.finite()&&v.n.finite());assert!(v.p.2>0.1&&v.p.2<30.0);}}
        for name in ["obj:cup","obj:saucer","obj:ashtray","obj:table","obj:chair/frame","obj:chair/weave","obj:lamp-near","obj:facade-0","obj:facade-1"] {assert!(ids.contains(&name.to_string()),"{name}");}
    }
    #[test] fn construction_adds_geometry_before_materials() {
        let scene=Scene::new(33,1.0).unwrap();let mut f=Frame::default();
        scene.frame(&mut f,0.0,12000.0,false,true).unwrap();assert!(f.triangles.is_empty()&&f.lines.is_empty());
        scene.frame(&mut f,1000.0,12000.0,false,true).unwrap();assert!(f.triangles.is_empty()&&!f.lines.is_empty());
        let mut last=0;
        for t in [3000.0,5000.0,7000.0,9000.0,12000.0] {scene.frame(&mut f,t,12000.0,false,false).unwrap();assert!(f.surfaces>=last);last=f.surfaces;}
        assert!(last>10000);
    }
    #[test] fn same_seed_time_is_deterministic_and_reduced_is_invariant() {
        let scene=Scene::new(33,1.0).unwrap();let mut a=Frame::default();let mut b=Frame::default();
        for t in [1000.0,6000.0,13000.0,24000.0] {scene.frame(&mut a,t,12000.0,false,true).unwrap();scene.frame(&mut b,t,12000.0,false,true).unwrap();assert_eq!(a.triangles,b.triangles);assert_eq!(a.lines,b.lines);}
        scene.frame(&mut a,1.0,12000.0,true,true).unwrap();scene.frame(&mut b,48000.0,12000.0,true,true).unwrap();assert_eq!(a.triangles,b.triangles);assert_eq!(a.lines,b.lines);
    }
    #[test] fn late_scene_stays_live_without_full_scene_randomness() {
        let scene=Scene::new(33,1.0).unwrap();let mut a=Frame::default();let mut b=Frame::default();
        scene.frame(&mut a,13000.0,12000.0,false,true).unwrap();scene.frame(&mut b,22000.0,12000.0,false,true).unwrap();
        assert_ne!(a.triangles,b.triangles);assert_eq!(a.tiles,TILE_COUNT);assert_eq!(b.tiles,TILE_COUNT);
        let static_vertices:usize=scene.objects.iter().map(|o|o.vertices.len()*STRIDE).sum();
        assert_eq!(&a.triangles[..static_vertices],&b.triangles[..static_vertices]);
    }
    #[test] fn input_and_resource_limits() {
        assert!(Scene::new(10000,1.0).is_err());assert!(Scene::new(33,f32::NAN).is_err());assert!(Scene::new(33,999.0).is_err());
        for seed in [0,33,9999] {let s=Scene::new(seed,2.0).unwrap();let mut f=Frame::default();
            for t in [0.0,4000.0,12000.0,20000.0,60000.0,3_600_000.0] {s.frame(&mut f,t,12000.0,false,true).unwrap();assert!(f.valid());}
            assert!(s.frame(&mut f,f64::NAN,12000.0,false,true).is_err());assert!(s.frame(&mut f,1.0,-1.0,false,true).is_err());}
    }
    #[test] fn fixed_camera_round_trips_design_anchors() {
        for [x,y,z] in [[0.36,0.7,5.0],[0.7,0.8,2.3],[0.45,0.2,14.0]] {let q=project(anchor(x,y,z));assert!((q[0]-x).abs()<1e-6&&(q[1]-y).abs()<1e-6);}
    }
}
