/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_rustrenderer_free: (a: number, b: number) => void;
export const rustrenderer_device: (a: number) => [number, number];
export const rustrenderer_dispose: (a: number) => void;
export const rustrenderer_inventory: (a: number) => [number, number];
export const rustrenderer_lose_context: (a: number) => void;
export const rustrenderer_new: (a: any, b: number, c: number) => [number, number, number];
export const rustrenderer_render: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
export const rustrenderer_restore_context: (a: number) => void;
export const rustrenderer_stats: (a: number) => [number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
