/* tslint:disable */
/* eslint-disable */

export class RustRenderer {
    free(): void;
    [Symbol.dispose](): void;
    device(): string;
    dispose(): void;
    inventory(): string;
    lose_context(): void;
    constructor(canvas: HTMLCanvasElement, seed: number, density: number);
    render(time_ms: number, build_ms: number, reduced: boolean, tiles: boolean, width: number, height: number): boolean;
    restore_context(): void;
    stats(): string;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_rustrenderer_free: (a: number, b: number) => void;
    readonly rustrenderer_device: (a: number) => [number, number];
    readonly rustrenderer_dispose: (a: number) => void;
    readonly rustrenderer_inventory: (a: number) => [number, number];
    readonly rustrenderer_lose_context: (a: number) => void;
    readonly rustrenderer_new: (a: any, b: number, c: number) => [number, number, number];
    readonly rustrenderer_render: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly rustrenderer_restore_context: (a: number) => void;
    readonly rustrenderer_stats: (a: number) => [number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
